# Script hebdo avec synthèse (placeholder)
print('Rapport hebdo généré')