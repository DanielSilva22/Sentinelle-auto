# Script quotidien (placeholder)
print('Sentinelle quotidienne lancée')